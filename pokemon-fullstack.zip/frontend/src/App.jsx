import React, { useState } from 'react'

const API = '/api';

export default function App() {
  const [nombre, setNombre] = useState('')
  const [jugador, setJugador] = useState(null)

  const handleLogin = async () => {
    const res = await fetch(`${API}/jugadores`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre })
    })
    const data = await res.json()
    setJugador(data)
  }

  if (jugador) {
    return (
      <div className="p-4">
        <h1 className="text-xl font-bold">Perfil de {jugador.nombre}</h1>
        <p>Monedas: {jugador.monedas}</p>
      </div>
    )
  }

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-2">Login</h1>
      <input value={nombre} onChange={e => setNombre(e.target.value)} placeholder="Nombre" className="border p-1 mr-2"/>
      <button onClick={handleLogin} className="bg-blue-500 text-white px-3 py-1">Entrar</button>
    </div>
  )
}
