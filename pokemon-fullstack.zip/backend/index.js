import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

let jugadores = [];

app.get("/api", (req, res) => {
  res.json({ message: "API funcionando en StackBlitz 🚀" });
});

app.post("/api/jugadores", (req, res) => {
  const { nombre } = req.body;
  let jugador = jugadores.find(j => j.nombre === nombre);
  if (!jugador) {
    jugador = { id: jugadores.length + 1, nombre, monedas: 100, inventario: [] };
    jugadores.push(jugador);
  }
  res.json(jugador);
});

const PORT = 4000;
app.listen(PORT, () => console.log(`Servidor en puerto ${PORT}`));
